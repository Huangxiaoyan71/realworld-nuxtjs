import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _475870f3 = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _9e196e30 = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _6dae1c80 = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _d8806600 = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _1c9051a7 = () => interopDefault(import('../pages/setting' /* webpackChunkName: "" */))
const _3b899736 = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _7a8a104d = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _475870f3,
    children: [{
      path: "",
      component: _9e196e30,
      name: "home"
    }, {
      path: "/login",
      component: _6dae1c80,
      name: "login"
    }, {
      path: "/register",
      component: _6dae1c80,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _d8806600,
      name: "profile"
    }, {
      path: "/setting",
      component: _1c9051a7,
      name: "setting"
    }, {
      path: "/editor",
      component: _3b899736,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _7a8a104d,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
